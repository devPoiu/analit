import random

def get_order_weight():
    return random.uniform(0.1, 20.0)

def select_transport(weight):
    if weight < 5:
        return "Bicycle"
    return "Car"

def calc_delivery_time(dist, speed): # добавить проверку на скорость не равной нулю
    if speed != 0:
        return dist / speed
    return 'infinity'

def apply_night_fee(cost, hour):
    if 22 <= hour or hour<= 6:   # условие не правильное
        return cost + 200
    return cost

def is_fragile():
    return random.choice([True, False])


if __name__ == "__main__":
    weight = get_order_weight()
    transport = select_transport(weight)
    distance = 10
    time = calc_delivery_time(distance, 0)
    total_cost = apply_night_fee(500, 23)
    print(f"Weight: {weight}, Transport: {transport}, ETA: {time} min, Cost: {total_cost}")