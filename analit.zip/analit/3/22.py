from PIL import Image, ImageChops, ImageDraw 
import random

def rgb_split(img, offset):
    r, g, b = img.split()
    r = ImageChops.offset(r, offset, 0)
    b = ImageChops.offset(b, -offset, 0)
    return Image.merge("RGB", (r, g, b))

def horizontal_shift(img):
    h = int(img.height * 0.05)
    y = random.randint(0, img.height - h)  # Ограничиваем y, чтобы y + 20 не вылез за край
    box = (0, y, img.width, y + h)
    part = img.crop(box)
    img.paste(part, (random.randint(-10, 10), y))
    
    return img

if __name__ == "__main__":
    img = Image.new("RGB", (200, 200), "blue")
    draw = ImageDraw.Draw(img)
    draw.rectangle([50, 0, 150, 200], fill="white")
    img.save("img.png")
    glitch = rgb_split(img, 5)
    for _ in range(10):
        glitch = horizontal_shift(glitch)
    glitch.save("glitch1.png")
