

def z1(p, m, f):
    return p + p*m + f

print(z1(1000,5,10))