import pytest
from script import fun, WeekDayName, newYear

def test_fun():
    assert fun('04') == 16
    assert fun('40') == 0
    assert fun(3) == 9

def test_WeekDayName():
    assert WeekDayName(3, 'ru') == 'среда'
    assert WeekDayName(3, 'eng') == 'Wednesday'
    assert WeekDayName(10, 'ru') == 'нет такого дня недели'

def test_newYear():
    assert newYear(3,18) == 288
    assert newYear(1,40) == -1
    assert newYear(-13,40) == -1