def fun(x):
    x = int(x)
    x = str(x)
    xx = 1
    if isinstance(x, (int, float)):
        x = str(x)
    for i in x:
        xx *= int(i)**2
    return int(xx)

def WeekDayName(n, lang):
    llang = {
        'ru': {
            1: 'понедельник',
            2: 'вторник',
            3: 'среда',
            4: 'четверг',
            5: 'пятница',
            6: 'суббота',
            7: 'воскресение',
        },
        'eng': {
            1: 'Monday',
            2: 'Tuesday',
            3: 'Wednesday',
            4: 'Thursday',
            5: 'Friday',
            6: 'Saturday',
            7: 'Sunday'
        }
    }

    if  0 < n < 8:
        return llang[lang][n]
    else :
        return 'нет такого дня недели'
    
def newYear(month, day):
    month -= 1
    year = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if 0 <= month < 13 and 0 < day < year[month]:
        sum = year[month] - day
        for i in range(month+1, len(year)):
            sum += year[i]
        return sum
    else:
        return -1


if __name__ == '__main__':
    print(fun('0344'))

    print()
    print(WeekDayName(3, 'ru'))
    print(WeekDayName(3, 'eng'))
    print(WeekDayName(10, 'ru'))

    print()
    print(newYear(3,18))
    print(newYear(1,40))
    print(newYear(-13,40))