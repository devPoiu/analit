def fun(x):
    xx = 1
    if isinstance(x, (int, float)):
        x = str(x)
    for i in x:
        xx *= int(i)**2
    return int(xx)

def WeekDayName(n, lang):
    llang = {
        'ru': {
            1: 'понедельник',
            2: 'вторник',
            3: 'среда',
            4: 'четверг',
            5: 'пятница',
            6: 'суббота',
            7: 'воскресение',
        },
        'eng': {
            1: 'Monday',
            2: 'Tuesday',
            3: 'Wednesday',
            4: 'Thursday',
            5: 'Friday',
            6: 'Saturday',
            7: 'Sunday'
        }
    }

    return llang[lang][n]

print(WeekDayName(3, 'ru'))
print(WeekDayName(3, 'eng'))

print(fun('0344'))
print(int(input()))